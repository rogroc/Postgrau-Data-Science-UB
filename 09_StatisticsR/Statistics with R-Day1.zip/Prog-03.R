airquality
airquality[1:5,]
class(airquality[1:5,])
airquality[1,1]
airquality[1,]
class(airquality$Ozone)
sum(airquality$Ozone)
sum(airquality$Ozone[!is.na(airquality$Ozone)])

