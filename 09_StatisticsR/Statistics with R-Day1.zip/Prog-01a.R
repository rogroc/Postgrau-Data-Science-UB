Bank1 <- read.table('http://www.ub.edu/rfa/docs/DATA/bank.csv', header=TRUE, sep=';')

View(Bank1)
names(Bank1)
