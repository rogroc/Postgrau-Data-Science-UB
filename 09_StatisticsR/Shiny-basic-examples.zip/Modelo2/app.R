library(shiny)
library(data.table)

RegData <- as.data.table(read.table(file="WHRData.csv", header = TRUE, sep=","))
RegData$RegionR=relevel(RegData$RegionR, ref="Western Europe")


ui <- fluidPage(
  headerPanel("Análisis del modelo de regresión"), 
  sidebarPanel(
    p("Selecciona la variable dependiente"),
    selectInput(inputId = "DepVar", label = "Variables Dependientes", multiple = FALSE, choices = list("HLE", "HS")),
    p("Selecciona las variables independientes"),
    selectInput(inputId = "IndVar", label = "Variables Independientes", multiple = TRUE, choices = list( "RegionR", "log_GDP", "HLE", "Family","Freedom","Generosity","Corruption"), selected = "log_GDP"),
    p("Selecciona el valor de la variable explicativa"),
    selectInput(inputId = "valor1", label = "Escenario RegionR", multiple = FALSE, choices = as.list(levels(RegData$RegionR))),
    sliderInput(inputId="valor2", label = "Escenario log_GDP",min=6, max=12, value=6.6, step=0.1),
    sliderInput(inputId="valor3", label = "Escenario HLE",min=40, max=80, value=44),
    sliderInput(inputId="valor4", label = "Escenario Family",min=0, max=1, value=0.1, step=0.01),
    sliderInput(inputId="valor5", label = "Escenario Freedom",min=0, max=1, value=0.1, step=0.01),
    sliderInput(inputId="valor6", label = "Escenario Generosity",min=0, max=1, value=0.1, step=0.01),
    sliderInput(inputId="valor7", label = "Escenario Corruption",min=0, max=1, value=0.1, step=0.01)
    ),
  mainPanel(
    p("Predicción de la variable dependiente"),
    verbatimTextOutput(outputId = "Predicc"),
    plotOutput("Plot"),
    p("Variables dependientes e independientes del modelo"),
    verbatimTextOutput(outputId = "IndPrint"),
    verbatimTextOutput(outputId = "DepPrint"),
    p("Estimación del modelo de regresión"),
    verbatimTextOutput(outputId = "RegSum")
  )
)

server <- function(input, output) {
  lm1 <- reactive({lm(reformulate(input$IndVar,input$DepVar), data = RegData)})
  data.predict= reactive({data.frame(RegionR=input$valor1, log_GDP=input$valor2,
                                   HLE=input$valor3, Family=input$valor4, Freedom=input$valor5
                                   , Generosity=input$valor6, Corruption=input$valor7)})
  pre1=reactive({predict(lm1(), data.predict())})
  output$DepPrint <- renderPrint({input$DepVar})
  output$IndPrint <- renderPrint({input$IndVar})
  output$RegSum <- renderPrint({summary(lm1())})
  output$Predicc <- renderPrint({pre1()})
  output$Plot <- renderPlot({barplot(pre1(), names.arg="", col = "darkred", horiz = TRUE, 
                                     xlim=if (input$DepVar=="HLE") {c(0,80)} else {c(0,8)}, ylab=input$DepVar)})
  
  
}

shinyApp(ui = ui, server = server)