library(shiny)
library(data.table)

RegData <- as.data.table(read.table(file="RegData.csv", header = TRUE, sep=";"))
lm(Y1~X1, data=RegData)
ui <- fluidPage(
  headerPanel("Regression"), 
  sidebarPanel(
    p("Select the inputs for the Dependent Variable"),
    selectInput(inputId = "DepVar", label = "Dependent Variables", multiple = FALSE, choices = list("Y1", "Y2")),
    p("Select the inputs for the Independent Variable"),
    selectInput(inputId = "IndVar", label = "Independent Variable", multiple = TRUE, choices = list( "X1", "X2", "X3", "X4"), selected = "X1"),
    p("Selecciona l'explicativa"),
    sliderInput(inputId="valor1", label = "Escenari X1",min=0, max=50, value=10),
    sliderInput(inputId="valor2", label = "Escenari X2",min=0, max=50, value=10),
    sliderInput(inputId="valor3", label = "Escenari X3",min=0, max=50, value=10),
    sliderInput(inputId="valor4", label = "Escenari X4",min=0, max=50, value=10)
    
  ),
  mainPanel(
    verbatimTextOutput(outputId = "Predicc"),
    verbatimTextOutput(outputId = "RegSum"),
    verbatimTextOutput(outputId = "IndPrint"),
    verbatimTextOutput(outputId = "DepPrint")
        #plotOutput("hist")
  )
)

server <- function(input, output) {
  
  lm1 <- reactive({lm(reformulate(input$IndVar,input$DepVar), data = RegData)})
  data.predict= reactive({data.frame(X1=input$valor1, X2=input$valor2,
                                   X3=input$valor3, X4=input$valor4)})
  pre1=reactive({predict(lm1(), data.predict())})
  output$DepPrint <- renderPrint({input$DepVar})
  output$IndPrint <- renderPrint({input$IndVar})
  output$RegSum <- renderPrint({summary(lm1())})
  output$Predicc <- renderPrint({pre1()})
  
  
}

shinyApp(ui = ui, server = server)