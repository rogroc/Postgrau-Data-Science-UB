#' A R4DSUB Function
#'
#' This function allows you to estimate a random forest model.
#' @param mydata name of the dataset.
#' @param myy model dependent variable
#' @param myregressors covariates
#' @keywords RF
#' @export
#' @examples PredictiveModel2(bank,y, age+duration)
#' cat_function()
PredictiveModel2<-function(mydataset, myregressors, myy){
  forest<-randomForest(as.factor(myy)~myregressors,data=mydataset, importance=TRUE, ntree=100)
  return(forest)
}
