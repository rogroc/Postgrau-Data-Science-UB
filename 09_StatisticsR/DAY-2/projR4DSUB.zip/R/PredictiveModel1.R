#' A R4DSUB Function
#'
#' This function allows you to estimate a logistic model.
#' @param mydata name of the dataset.
#' @param myformula model formula
#' @keywords logit
#' @export
#' @examples PredictiveModel1(bank,y~age+duration)
#' cat_function()
PredictiveModel1<-function(mydataset,myformula){
  mod1<-glm(myformula, mydataset, family=binomial)
  return(mod1)
}
