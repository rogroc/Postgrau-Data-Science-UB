$(document).ready(function(){
var s = "The text to scrape is: ";
$('div').append(s + "<div id = 'scbox'> " + Math.floor(Math.random() * 100) + " euros </div>");
});
