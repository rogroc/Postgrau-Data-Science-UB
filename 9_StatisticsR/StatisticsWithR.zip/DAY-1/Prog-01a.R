Bank1 <- read.table('http://www.ub.edu/rfa/docs/DATA/bank.csv', header=TRUE, sep=';')

view(Bank1)
names(Bank1)
